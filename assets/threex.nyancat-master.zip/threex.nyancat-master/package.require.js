define( [ 'module'
	, './threex.nyancat.js'
	, './threex.nyancatrainbow.js'
	, './threex.nyancatsound.js'
	, './threex.nyancatstars.js'
	], function(module){
	THREEx.NyanCatSound.baseURL	= module.uri+'/../'
});